package MySchoolProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.Random;

public class MySchoolProject extends JFrame {

    private static MySchoolProject schoolGame;
    private static Image happyShkolnik;
    private static Image sadShkolnik;
    private static boolean isHappy = true; // Состояние школьника
    private static JLabel taskLabel;
    private static JTextField answerField;
    private static JButton submitButton;
    private static int correctAnswer;
    private static Random random = new Random();

    public static void main(String[] args) throws IOException {

        // Загрузка изображений школьника
        happyShkolnik = ImageIO.read(MySchoolProject.class.getResourceAsStream("shkolnik.png"));
        sadShkolnik = ImageIO.read(MySchoolProject.class.getResourceAsStream("sad.png"));

        // Настройка окна
        schoolGame = new MySchoolProject();
        schoolGame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        schoolGame.setLocation(200, 50);
        schoolGame.setSize(900, 600);
        schoolGame.setResizable(false);

        SchoolField schoolField = new SchoolField();
        schoolGame.add(schoolField);

        // Панель с примером и вводом ответа
        JPanel taskPanel = new JPanel();
        taskPanel.setLayout(new FlowLayout());
        taskLabel = new JLabel();
        generateNewTask();  // Генерация первого примера
        answerField = new JTextField(5);
        submitButton = new JButton("Submit");

        // Добавление слушателя для кнопки "Submit"
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkAnswer();  // Проверка ответа
            }
        });

        taskPanel.add(taskLabel);
        taskPanel.add(answerField);
        taskPanel.add(submitButton);

        // Добавляем панель в окно
        schoolGame.add(taskPanel, BorderLayout.NORTH);

        schoolGame.setVisible(true);
    }

    // Метод для генерации нового математического примера
    public static void generateNewTask() {
        int a = random.nextInt(10);  // Случайное число от 0 до 9
        int b = random.nextInt(10);  // Случайное число от 0 до 9
        correctAnswer = a + b;  // Правильный ответ
        taskLabel.setText("Solve: " + a + " + " + b + " = ?");
    }

    // Метод для проверки ответа пользователя
    public static void checkAnswer() {
        try {
            int userAnswer = Integer.parseInt(answerField.getText());
            if (userAnswer == correctAnswer) {
                isHappy = true;  // Школьник улыбается
            } else {
                isHappy = false; // Школьник грустит
            }
            answerField.setText("");  // Очистка поля для ввода
            generateNewTask();        // Генерация нового примера
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(schoolGame, "Please enter a valid number!");
        }
    }

    // Класс, отвечающий за отрисовку школьника
    public static class SchoolField extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Отрисовка школьника в правом нижнем углу
            Image shkolnikImage = isHappy ? happyShkolnik : sadShkolnik;
            g.drawImage(shkolnikImage, getWidth() - shkolnikImage.getWidth(null) - 10,
                    getHeight() - shkolnikImage.getHeight(null) - 10, null);
            repaint();
        }
    }
}
